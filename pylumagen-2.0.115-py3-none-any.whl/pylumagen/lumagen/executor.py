"""Module: CommandExecutor.

Handles execution of device commands by grouping them into specialized command handlers.
This improves **organization**, **maintainability**, and **structured control** over the device.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import TYPE_CHECKING

from pylumagen.models.constants import DeviceStatus
from pylumagen.utils.logging_utils import LoggingMixin

from .commands import (ASCII_COMMAND_LIST, CMD_DEVICE_START,
                       DEVICE_AUTOASPECT_QUERY, DEVICE_BASIC_OUTPUT_INFO,
                       DEVICE_DISPLAY_CLEAR, DEVICE_DISPLAY_INPUT_ASPECT,
                       DEVICE_DISPLAY_MSG, DEVICE_FAN_SPEED, DEVICE_FULL_V4,
                       DEVICE_GAMEMODE, DEVICE_GAMEMODE_QUERY, DEVICE_HOTPLUG,
                       DEVICE_LABEL_QUERY, DEVICE_OUTPUT_COLOR_FORMAT,
                       DEVICE_OUTPUT_MODE, DEVICE_SET_LABEL, INPUT_BASIC_INFO,
                       INPUT_VIDEO, STATUS_ID, STATUS_POWER)
from .connection import BaseHandler
from .messages import Request, Response, GetLabelQuery

if TYPE_CHECKING:  # pragma: no cover
    from .device import DeviceManager


class CommandSender(LoggingMixin):
    """Handles sending raw commands to the device."""

    def __init__(self, connection_handler: BaseHandler) -> None:
        """Initialize with a connection handler."""
        super().__init__()
        self._handler = connection_handler

    async def send_command(self, command: str | list[str] | Request) -> None | Response:
        """Send a command or list of commands over the connection."""

        try:
            if isinstance(command, Request):
                return await self._handler.send(command)
            if isinstance(command, str):
                commands = [command.strip()] if command.strip() else []
            elif isinstance(command, list):
                commands = [
                    cmd.strip()
                    for cmd in command
                    if isinstance(cmd, str) and cmd.strip()
                ]
            else:
                self.log.error("Invalid command type: %s", type(command).__name__)
                return

            if not commands:
                self.log.warning("No valid commands to send after filtering.")
                return

            await self._handler.queue_command(commands)
        except AttributeError as e:
            self.log.error("Attribute error in send_command(): %s", e)
        except TypeError as e:
            self.log.error("Type error in send_command(): %s", e)
        except asyncio.exceptions.TimeoutError as e:
            self.log.error("Timeout while sending command: %s", e)
        except ConnectionError as e:
            self.log.error("Connection error while sending command: %s", e)
        except RuntimeError as e:
            self.log.error("Runtime error while sending command: %s", e)

    async def send_remote_command(self, value: str, key: str = "remote") -> None:
        """Send a command by looking up a key-value pair in ASCII_COMMAND_LIST."""

        cmd = {j.get(key): i for i, j in ASCII_COMMAND_LIST.items()}.get(value)

        if cmd:
            self.log.debug("Sending remote command: %s, (%s)", cmd, value)
            await self.send_command(cmd)
        else:
            self.log.warning(
                "Command not found for value: %s (searched by key: %s)", value, key
            )
            raise ValueError(f"Invalid remote command value: {value}")


class AspectControl(LoggingMixin):
    """Handles source aspect ratio commands."""

    def __init__(self, sender: CommandSender) -> None:
        """Initialize with a command sender."""
        super().__init__()
        self.sender = sender

    async def source_aspect_4x3(self) -> None:
        """Set source aspect ratio to 4:3."""
        await self.sender.send_remote_command("4:3")

    async def source_aspect_16x9(self) -> None:
        """Set source aspect ratio to 16:9."""
        await self.sender.send_remote_command("16:9")

    async def source_aspect_1_85(self) -> None:
        """Send SOURCE ASPECT 1.85 command."""
        await self.sender.send_remote_command("1.85")

    async def source_aspect_1_90(self) -> None:
        """Send SOURCE ASPECT 1.90 command."""
        await self.sender.send_remote_command("1.90")

    async def source_aspect_2_00(self) -> None:
        """Send SOURCE ASPECT 2.00 command."""
        await self.sender.send_remote_command("2.00")

    async def source_aspect_2_10(self) -> None:
        """Send SOURCE ASPECT 2.10 command."""
        await self.sender.send_remote_command("2.10")

    async def source_aspect_2_20(self) -> None:
        """Send SOURCE ASPECT 2.20 command."""
        await self.sender.send_remote_command("2.20")

    async def source_aspect_2_35(self) -> None:
        """Send SOURCE ASPECT 2.35 command."""
        await self.sender.send_remote_command("2.35")

    async def source_aspect_2_40(self) -> None:
        """Send SOURCE ASPECT 2.40 command."""
        await self.sender.send_remote_command("2.40")

    async def send_source_aspect_2_55(self) -> None:
        """Send SOURCE ASPECT 2.55 command."""
        await self.sender.send_remote_command("2.55")

    async def send_source_aspect_2_76(self) -> None:
        """Send SOURCE ASPECT 2.76 command."""
        await self.sender.send_remote_command("2.76")

    async def source_aspect_lbox(self) -> None:
        """Send SOURCE ASPECT Letterbox (LBOX) command."""
        await self.sender.send_remote_command("LBOX")


class AspectControlMixin():
    """Mixin for handling aspect ratio commands."""

    aspect: AspectControl
    log: logging.Logger


    async def source_aspect_4x3(self) -> None:
        """Set the source aspect ratio to 4:3."""
        await self.aspect.source_aspect_4x3()

    async def source_aspect_16x9(self) -> None:
        """Set the source aspect ratio to 16:9."""
        await self.aspect.source_aspect_16x9()

    async def source_aspect_1_85(self) -> None:
        """Set the source aspect ratio to 1.85:1."""
        await self.aspect.source_aspect_1_85()

    async def source_aspect_1_90(self) -> None:
        """Set the source aspect ratio to 1.90:1."""
        await self.aspect.source_aspect_1_90()

    async def source_aspect_2_00(self) -> None:
        """Set the source aspect ratio to 2.00:1."""
        await self.aspect.source_aspect_2_00()

    async def source_aspect_2_10(self) -> None:
        """Set the source aspect ratio to 2.10:1."""
        await self.aspect.source_aspect_2_10()

    async def source_aspect_2_20(self) -> None:
        """Set the source aspect ratio to 2.20:1."""
        await self.aspect.source_aspect_2_20()

    async def source_aspect_2_35(self) -> None:
        """Set the source aspect ratio to 2.35:1."""
        await self.aspect.source_aspect_2_35()

    async def source_aspect_2_40(self) -> None:
        """Set the source aspect ratio to 2.40:1."""
        await self.aspect.source_aspect_2_40()

    async def source_aspect_2_55(self) -> None:
        """Set the source aspect ratio to 2.55:1."""
        await self.aspect.send_source_aspect_2_55()

    async def source_aspect_2_76(self) -> None:
        """Set the source aspect ratio to 2.76:1."""
        await self.aspect.send_source_aspect_2_76()

    async def source_aspect_lbox(self) -> None:
        """Set the source aspect ratio to Letterbox (LBOX)."""
        await self.aspect.source_aspect_lbox()


class LabelControl:
    """Handles querying and setting of input and feature labels on the device."""

    def __init__(self, sender: CommandSender, device_manager: DeviceManager) -> None:
        """
        Initialize label control with a command sender and device manager.

        Args:
            sender: Responsible for sending commands to the device.
            device_manager: Tracks device state and label mappings.
        """
        self.sender = sender
        self.device_manager = device_manager

    async def get_labels(self, get_all: bool = True) -> None:
        """
        Query labels from the device.

        Label types:
            - Inputs: X = 'A'-'D', Y = 09 (or just 'A' if get_all=False)
            - Custom Modes: X = '1', Y = 07
            - CMS: X = '2', Y = 07
            - Style: X = '3', Y = 07

        Args:
            get_all: If True, fetch all input and extended labels.
                     If False, only query labels for input memory 'A'.
        """
        self.device_manager.expecting_full_labels = get_all
        self.device_manager.labels = {}
        commands = []

        if get_all:
            # Input labels A-D, 0-9
            for x in range(ord("A"), ord("D") + 1):
                for y in reversed(range(10)):
                    label = f"{chr(x)}{y}"
                    commands.append(f"{CMD_DEVICE_START}{DEVICE_LABEL_QUERY}{label}")

            # Extended labels: Custom modes, CMS, style
            for x in range(1, 4):
                for y in range(8):
                    label = f"{x}{y}"
                    commands.append(f"{CMD_DEVICE_START}{DEVICE_LABEL_QUERY}{label}")

        else:
            # Only input memory A, 0-9
            for y in reversed(range(10)):
                label = f"A{y}"
                commands.append(f"{CMD_DEVICE_START}{DEVICE_LABEL_QUERY}{label}")

        self.sender.log.debug("Sending %d label query commands...", len(commands))
        self.sender.log.debug(commands)
        await self.sender.send_command(commands)
        self.sender.log.debug("Label query commands sent.")


    async def set_labels(self, port_config: dict[str, str] | None = None) -> None:
        """
        Set or override labels on the device.

        Args:
            port_config: A dictionary like {"A0": "Blu-ray", "11": "Custom1"}.
                         If None, defaults to HDMI-style labels for A0D9.
        """
        if port_config is None:
            port_config = {
                f"{x}{y}": f"HDMI {x}{y}" for x in "ABCD" for y in "0123456789"
            }

        valid_key_pattern = re.compile(r"^[ABCD][0-9]$|^[123][0-7]$")
        max_label_length = {"A": 10, "B": 10, "C": 10, "D": 10, "1": 7, "2": 7, "3": 7}

        commands = []
        for key, label in port_config.items():
            if valid_key_pattern.match(key):
                prefix = key[0]
                max_len = max_label_length.get(prefix, 8)
                trimmed = label[:max_len]
                commands.append(f"{DEVICE_SET_LABEL}{key}{trimmed}")

        if not commands:
            self.sender.log.warning("No valid label commands to send.")
            return

        self.sender.log.debug("Sending %d label set commands...", len(commands))
        await self.sender.send_command(commands)
        self.sender.log.debug("Label set commands sent.")


class LabelControlMixin:
    """Provides high-level access to label management for inputs and video processing modes."""

    label: LabelControl

    async def get_labels(self, get_all: bool = True) -> None:
        """Fetch labels from the device.

        Retrieves labels for inputs or video processing features depending on the underlying
        label type context.

        - Input labels: X = 'A''D', Y = input - 1
        - Custom mode: X = '1', Y = 07
        - CMS         : X = '2', Y = 07
        - Style       : X = '3', Y = 07

        Args:
            get_all: If True, retrieves all label categories supported by the device.
        """
        await self.label.get_labels(get_all=get_all)

    async def set_labels(self, port_config: dict[str, str] | None = None) -> None:
        """Apply or update label names on the device.

        Args:
            port_config: A dictionary mapping label identifiers (e.g., "A0", "12", "30") to
                         human-readable names. The identifier format depends on the label type:
                         - "A0": Input 1 on input memory A
                         - "11": Custom mode #1
                         - "20": CMS #0
                         - "37": Style #7
        """
        await self.label.set_labels(port_config)


class MessageControl(LoggingMixin):
    """Handles messages on display."""

    def __init__(self, sender: CommandSender, device_manager: DeviceManager) -> None:
        """Initialize with a command sender and device manager."""
        super().__init__()
        self.sender = sender
        self.dm = device_manager

    async def display_message(self, timeout: int, message: str) -> None:
        """Send a Display Message command (timeout: 0-9, 9 keeps displayed until "ZC").

        Args:
            timeout (int): 0 to 9, where 9 keeps the message displayed until "ZC" is sent.
            message (str): The message to display (supports 2 lines, 30 chars each).

        Only allows ASCII characters (0x20-0x7A). ASCII extended characters allowed for volume bars.

        """

        if not isinstance(timeout, int) or not 0 <= timeout <= 9:
            raise ValueError(
                f"Invalid timeout: {timeout}. Must be an integer between 0 and 9."
            )

        if not isinstance(message, str) or not message.strip():
            raise ValueError("Message must be a non-empty string.")

        # Filter message to only include allowed ASCII characters
        sanitized_message = "".join(
            char for char in message if 0x20 <= ord(char) <= 0x7A
        )

        if not sanitized_message:
            self.log.warning("Filtered message is empty after character sanitization.")
            return

        command = f"{DEVICE_DISPLAY_MSG}{timeout}{sanitized_message}"

        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning("Cannot display message. Device is not in ACTIVE mode.")
            return

        self.log.debug(
            "Sending show message command: '%s' with timeout %d",
            sanitized_message,
            timeout,
        )
        await self.sender.send_command(command)
        self.log.debug("Message sent successfully.")

    async def clear_message(self) -> None:
        """Send Clear Message command to the device."""

        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning("Cannot clear message. Device is not in ACTIVE mode.")
            return

        await self.sender.send_command(DEVICE_DISPLAY_CLEAR)


class MessageControlMixin:
    """Mixin for handling display message commands."""

    message: MessageControl

    async def display_message(self, timeout: int, message: str) -> None:
        """Send a Display Message command to the device..

        Args:
            timeout (int): 0 to 9, where 9 keeps the message displayed until "ZC" is sent.
            message (str): The message to display (supports 2 lines, 30 chars each).

        Only allows ASCII characters (0x20-0x7A). ASCII extended characters allowed for volume bars.

        """
        await self.message.display_message(timeout, message)

    async def clear_message(self) -> None:
        """Send a Clear Message command to the device."""
        await self.message.clear_message()


class NavigationControl:
    """Handles remote commands for navigation."""

    def __init__(self, sender: CommandSender) -> None:
        """Initialize with a command sender."""
        self.sender = sender

    async def down(self) -> None:
        """Send DOWN command."""
        await self.sender.send_remote_command("v")

    async def exit(self) -> None:
        """Send EXIT command (exit current menu or screen)."""
        await self.sender.send_remote_command("EXIT")

    async def enter(self) -> None:
        """Send ENTER command (confirm selection)."""
        await self.sender.send_remote_command("ENTER")

    async def home(self) -> None:
        """Send HOME command (return to the main screen)."""
        await self.sender.send_remote_command("HOME")

    async def left(self) -> None:
        """Send LEFT command."""
        await self.sender.send_remote_command("<")

    async def menu(self) -> None:
        """Send MENU command (open settings menu)."""
        await self.sender.send_remote_command("MENU")

    async def ok(self) -> None:
        """Send OK command."""

        await self.sender.send_remote_command("Accept command", key="desc")

    async def right(self) -> None:
        """Send RIGHT command."""
        await self.sender.send_remote_command(">")

    async def up(self) -> None:
        """Send UP command."""
        await self.sender.send_remote_command("^")


class NavigationControlMixin:
    """Mixin for handling navigation commands."""

    navigation: NavigationControl  # Type hint for IDE support

    async def down(self) -> None:
        """Send DOWN command."""
        await self.navigation.down()

    async def exit(self) -> None:
        """Send EXIT command (exit current menu or screen)."""
        await self.navigation.exit()

    async def enter(self) -> None:
        """Send ENTER command (confirm selection)."""
        await self.navigation.enter()

    async def home(self) -> None:
        """Send HOME command (return to the main screen)."""
        await self.navigation.home()

    async def left(self) -> None:
        """Send LEFT command."""
        await self.navigation.left()

    async def menu(self) -> None:
        """Send MENU command (open settings menu)."""
        await self.navigation.menu()

    async def ok(self) -> None:
        """Send OK command."""
        await self.navigation.ok()

    async def right(self) -> None:
        """Send RIGHT command."""
        await self.navigation.right()

    async def up(self) -> None:
        """Send UP command."""
        await self.navigation.up()


class PowerControl:
    """Handles power state transitions."""

    def __init__(self, sender: CommandSender) -> None:
        """Initialize with a command sender and device manager."""
        self.sender = sender

    async def standby(self) -> None:
        """Put the device in standby mode."""
        await self.sender.send_remote_command("STBY")

    async def power_on(self) -> None:
        """Turn the device on."""
        await self.sender.send_remote_command("ON")


class PowerControlMixin:
    """Mixin for power state transitions."""

    power: PowerControl

    async def standby(self) -> None:
        """Put the device in standby mode."""
        await self.power.standby()

    async def power_on(self) -> None:
        """Turn the device on."""
        await self.power.power_on()


class RemoteControl(LoggingMixin):
    """Handles remote commands for menus and settings."""

    def __init__(self, sender: CommandSender, device_manager: DeviceManager) -> None:
        """Initialize with a command sender."""
        super().__init__()
        self.sender = sender
        self.dm = device_manager

    async def alt(self) -> None:
        """Send ALT command."""

        await self.sender.send_remote_command("ALT")

    async def auto_aspect_disable(self) -> None:
        """Send AUTO ASPECT DISABLE command."""

        await self.sender.send_remote_command("AAD")
        await self.sender.send_command(f"{CMD_DEVICE_START}{DEVICE_AUTOASPECT_QUERY}")

    async def auto_aspect_enable(self) -> None:
        """Send AUTO ASPECT ENABLE command."""

        await self.sender.send_remote_command("AAE")
        await self.sender.send_command(f"{CMD_DEVICE_START}{DEVICE_AUTOASPECT_QUERY}")

    async def clear(self) -> None:
        """Send CLEAR command to the device."""

        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning("Cannot send CLEAR command. Device is not in ACTIVE mode.")
            return

        await self.sender.send_remote_command("CLR")

    async def fanspeed(self, speed: int) -> None:
        """Send FANSPEED command to the device.

        Args:
            speed (int): 1-10 for speeds, translated internally to 0-9.

        """
        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning(
                "Cannot send FANSPEED command. Device is not in ACTIVE mode."
            )
            return

        if not 1 <= speed <= 10:
            self.log.error("Invalid Fan Speed. Must be between 1 and 10.")
            return

        translated_speed = speed - 1

        command = f"{DEVICE_FAN_SPEED}{translated_speed}"
        await self.sender.send_command(command)

    async def hdr(self) -> None:
        """Send HDR setup command to the device."""

        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning("Cannot send HDR command. Device is not in ACTIVE mode.")
            return

        await self.sender.send_remote_command("HDR")

    async def help(self) -> None:
        """Send HELP command to the device."""

        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning("Cannot send HELP command. Device is not in ACTIVE mode.")
            return

        await self.sender.send_remote_command("HELP")

    async def hotplug(self, x: str = "A") -> None:
        """Send HOTPLUG command to the device.

        Args:
            x (str, optional): HDMI input identifier ('0'-'9' for HDMI 1-10,
            'A' for all inputs). Defaults to "A".

        """
        if self.dm.device_status != DeviceStatus.ACTIVE:
            self.log.warning(
                "Cannot send HOTPLUG command. Device is not in ACTIVE mode."
            )
            return

        valid_inputs = {str(i) for i in range(10)} | {"A"}

        if x not in valid_inputs:
            self.log.error("Invalid HDMI input. Must be '0'-'9' or 'A'.")
            return

        command = f"{DEVICE_HOTPLUG}{x}"
        await self.sender.send_command(command)

    async def info(self) -> None:
        """Send INFO command (display system information)."""
        await self.sender.send_remote_command("INFO")

    async def input(self, index: int) -> None:
        """Send INPUT command with the specified index."""

        if not isinstance(index, int) or index < 0:
            raise ValueError(
                f"Invalid input index: {index}. Must be a non-negative integer."
            )

        if index >= 10:
            command = f"i+{index - 10}"
        else:
            command = f"i{index}"

        await self.sender.send_command(command)

    async def mema(self) -> None:
        """Send send MEMA command."""

        await self.sender.send_remote_command("MEMA")

    async def memb(self) -> None:
        """Send MEMB command."""

        await self.sender.send_remote_command("MEMB")

    async def memc(self) -> None:
        """Send MEMC command."""

        await self.sender.send_remote_command("MEMC")

    async def memd(self) -> None:
        """Send MEMD command."""

        await self.sender.send_remote_command("MEMD")

    async def nls(self) -> None:
        """Send NLS command."""

        await self.sender.send_remote_command("NLS")

    async def pattern(self) -> None:
        """Send Pattern command."""

        await self.sender.send_remote_command("Pattern")

    async def prev(self) -> None:
        """Send Previous command."""

        await self.sender.send_remote_command("PREV")

    async def save(self) -> None:
        """Send SAVE command."""
        await self.sender.send_remote_command("Save")

    async def send_0(self) -> None:
        """Send 0 command."""
        await self.sender.send_remote_command("0")

    async def send_1(self) -> None:
        """Send 1 command."""
        await self.sender.send_remote_command("1")

    async def send_2(self) -> None:
        """Send 2 command."""
        await self.sender.send_remote_command("2")

    async def send_3(self) -> None:
        """Send 3 command."""
        await self.sender.send_remote_command("3")

    async def send_4(self) -> None:
        """Send 4 command."""
        await self.sender.send_remote_command("4")

    async def send_5(self) -> None:
        """Send 5 command."""
        await self.sender.send_remote_command("5")

    async def send_6(self) -> None:
        """Send 6 command."""
        await self.sender.send_remote_command("6")

    async def send_7(self) -> None:
        """Send 7 command."""
        await self.sender.send_remote_command("7")

    async def send_8(self) -> None:
        """Send 8 command."""
        await self.sender.send_remote_command("8")

    async def send_9(self) -> None:
        """Send 9 command."""
        await self.sender.send_remote_command("9")

    async def send_10(self) -> None:
        """Send 10 command."""
        await self.sender.send_remote_command("10+")

    async def set_game_mode(self, state: int) -> None:
        """Send SET GAME MODE command."""

        await self.sender.send_command(
            [f"{DEVICE_GAMEMODE}{state}", f"{CMD_DEVICE_START}{DEVICE_GAMEMODE_QUERY}"]
        )

    async def show_aspect(self) -> None:
        """Send SHOW INPUT ASPECT command."""

        await self.sender.send_command(DEVICE_DISPLAY_INPUT_ASPECT)

    async def zone(self) -> None:
        """Send ZONE command."""

        await self.sender.send_remote_command("ZONE")


class RemoteControlMixin:
    """Mixin for handling remote commands for menus and settings."""

    remote: RemoteControl

    async def alt(self) -> None:
        """Send ALT command."""
        await self.remote.alt()

    async def auto_aspect_disable(self) -> None:
        """Send AUTO ASPECT DISABLE command."""
        await self.remote.auto_aspect_disable()

    async def auto_aspect_enable(self) -> None:
        """Send AUTO ASPECT ENABLE command."""
        await self.remote.auto_aspect_enable()

    async def clear(self) -> None:
        """Send CLEAR command to the device."""
        await self.remote.clear()

    async def fanspeed(self, speed: int) -> None:
        """Send FANSPEED command to the device.

        Args:
            speed (int): 1-10 for speeds.

        """
        await self.remote.fanspeed(speed)

    async def hotplug(self, x: str = "A") -> None:
        """Send HOTPLUG command to the device."""
        await self.remote.hotplug(x)

    async def hdr(self) -> None:
        """Send HDR setup command to the device."""
        await self.remote.hdr()

    async def help(self) -> None:
        """Send HELP command to the device."""
        await self.remote.help()

    async def info(self) -> None:
        """Send INFO command (display system information)."""
        await self.remote.info()

    async def input(self, index: int) -> None:
        """Send INPUT command with the specified index."""
        await self.remote.input(index)

    async def mema(self) -> None:
        """Send MEMA command."""
        await self.remote.mema()

    async def memb(self) -> None:
        """Send MEMB command."""
        await self.remote.memb()

    async def memc(self) -> None:
        """Send MEMC command."""
        await self.remote.memc()

    async def memd(self) -> None:
        """Send MEMD command."""
        await self.remote.memd()

    async def nls(self) -> None:
        """Send NLS command."""
        await self.remote.nls()

    async def pattern(self) -> None:
        """Send Pattern command."""
        await self.remote.pattern()

    async def prev(self) -> None:
        """Send Previous command."""
        await self.remote.prev()

    async def send_0(self) -> None:
        """Send 0 command."""
        await self.remote.send_0()

    async def send_1(self) -> None:
        """Send 1 command."""
        await self.remote.send_1()

    async def send_2(self) -> None:
        """Send 2 command."""
        await self.remote.send_2()

    async def send_3(self) -> None:
        """Send 3 command."""
        await self.remote.send_3()

    async def send_4(self) -> None:
        """Send 4 command."""
        await self.remote.send_4()

    async def send_5(self) -> None:
        """Send 5 command."""
        await self.remote.send_5()

    async def send_6(self) -> None:
        """Send 6 command."""
        await self.remote.send_6()

    async def send_7(self) -> None:
        """Send 7 command."""
        await self.remote.send_7()

    async def send_8(self) -> None:
        """Send 8 command."""
        await self.remote.send_8()

    async def send_9(self) -> None:
        """Send 9 command."""
        await self.remote.send_9()

    async def send_10(self) -> None:
        """Send 10 command."""
        await self.remote.send_10()

    async def set_game_mode(self, state: int) -> None:
        """Send SET GAME MODE command."""
        await self.remote.set_game_mode(state)

    async def show_aspect(self) -> None:
        """Send SHOW INPUT ASPECT command."""
        await self.remote.show_aspect()

    async def zone(self) -> None:
        """Send ZONE command."""
        await self.remote.zone()


class CommandExecutor(
    LoggingMixin,
    AspectControlMixin,
    LabelControlMixin,
    MessageControlMixin,
    NavigationControlMixin,
    PowerControlMixin,
    RemoteControlMixin,
):
    """The main command executor that combines all functionality."""

    def __init__(
        self, connection_handler: BaseHandler, device_manager: DeviceManager
    ) -> None:
        """Initialize and set up all command groups.

        Args:
            connection_handler (BaseHandler): The device connection handler.
            device_manager (DeviceManager): The device manager instance.

        """
        super().__init__()
        self.dm = device_manager
        self.sender = CommandSender(connection_handler)

        self._controls = {
            "aspect": AspectControl(self.sender),
            "label": LabelControl(self.sender, self.dm),
            "message": MessageControl(self.sender, self.dm),
            "navigation": NavigationControl(self.sender),
            "power": PowerControl(self.sender),
            "remote": RemoteControl(self.sender, self.dm),
        }

        self.aspect = self._controls["aspect"]
        self.label = self._controls["label"]
        self.message = self._controls["message"]
        self.navigation = self._controls["navigation"]
        self.power = self._controls["power"]
        self.remote = self._controls["remote"]

    def __getattr__(self, name):
        """Efficiently resolve attributes dynamically with caching."""

        if name in self._controls:
            setattr(self, name, self._controls[name])
            return self._controls[name]

        for control in self._controls.values():
            if hasattr(control, name):
                setattr(self, name, getattr(control, name))
                return getattr(self, name)

        raise AttributeError(
            f"'{self.__class__.__name__}' object has no attribute '{name}'"
        )

    async def send_command(self, command: str) -> None:
        """Send a command using the main executor."""
        await self.sender.send_command(command)

    async def send_remote_command(self, value: str, key: str = "remote") -> None:
        """Send a remote command through the executor."""
        await self.sender.send_remote_command(value, key)

    async def get_all(self, exclude_status: bool = False) -> str:
        """Retrieve all system information by sending multiple commands.

        - If `exclude_status` is True, excludes STATUS_ID, STATUS_POWER, and DEVICE_FULL_V4.

        Args:
            exclude_status (bool, optional): Whether to exclude status-related queries.

        Returns:
            str: Confirmation message that commands were sent.

        """

        command_types = [
            STATUS_ID,
            STATUS_POWER,
            INPUT_BASIC_INFO,
            INPUT_VIDEO,
            DEVICE_FULL_V4,
            DEVICE_BASIC_OUTPUT_INFO,
            DEVICE_OUTPUT_MODE,
            DEVICE_OUTPUT_COLOR_FORMAT,
            DEVICE_GAMEMODE_QUERY,
            DEVICE_AUTOASPECT_QUERY,
        ]

        if exclude_status:
            command_types = [
                cmd
                for cmd in command_types
                if cmd not in {STATUS_ID, STATUS_POWER, DEVICE_FULL_V4}
            ]

        if not command_types:
            self.sender.log.warning("No commands to send in get_all() after exclusion.")
            return ""

        commands = [f"{CMD_DEVICE_START}{cmd}" for cmd in command_types]

        self.sender.log.debug("Sending commands: %s", commands)

        await self.send_command(commands)

        if exclude_status:
            self.sender.log.debug(
                "Device event cleared after excluding status commands."
            )
            self.dm.context.device_state.device_event.clear()
        else:
            self.sender.log.debug("Device event set after sending all commands.")
            self.dm.context.device_state.device_event.set()

        return "Commands sent successfully."
