"""Constants."""

from enum import Enum, IntEnum


class ConnectionStatus(Enum):
    """Enum for connection statuses."""

    CONNECTED = "connected"
    DISCONNECTED = "disconnected"


class EventType(Enum):
    """Enum for valid event types."""

    CONNECTION_STATE = "connection_state"
    DATA_RECEIVED = "data_received"
    STATE_CHANGED = "state_changed"


class DeviceStatus(str, Enum):
    """Enum for device status (whether it's on or in standby)."""

    STANDBY = "Standby"
    ACTIVE = "Active"


class Frame3DTypeEnum(IntEnum):
    """Enum for frame format and input 3D type."""

    OFF = 0
    FRAME_PACKED = 2
    TOP_BOTTOM = 4
    SIDE_BY_SIDE = 8

    def __str__(self):
        """Return a human-readable string for the enum."""
        return {
            Frame3DTypeEnum.OFF: "Off",
            Frame3DTypeEnum.FRAME_PACKED: "Frame Packed",
            Frame3DTypeEnum.TOP_BOTTOM: "Top-Bottom",
            Frame3DTypeEnum.SIDE_BY_SIDE: "Side-by-Side",
        }[self]


class InputMemoryEnum(str, Enum):
    """Enum for input memory."""

    A = "A"
    B = "B"
    C = "C"
    D = "D"


class InputStatus(IntEnum):
    """Enum for video status."""

    NONE = 0
    VIDEO_ACTIVE = 1
    TEST_PATTERN_ACTIVE = 2

    def __str__(self):
        """Return String."""
        return {
            InputStatus.NONE: "No Source",
            InputStatus.VIDEO_ACTIVE: "Active Video",
            InputStatus.TEST_PATTERN_ACTIVE: "Internal Pattern",
        }[self]


class StateStatus(str, Enum):
    """Enum representing possible state statuses."""

    DISABLED = "Disabled"
    ENABLED = "Enabled"
