"""Handles serial and IP communication using asyncio.

This module provides common functionality for serial and IP connections
with shared methods for opening, closing, sending, and receiving data.
"""

from __future__ import annotations  # noqa: I001

import asyncio
import contextlib
from abc import abstractmethod
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import serial_asyncio_fast as serial_asyncio

from pylumagen.models.constants import ConnectionStatus, EventType
from pylumagen.utils.logging_utils import LoggingMixin, custom_log_pprint
from pylumagen.utils.task_manager import TaskManager

from .commands import (ASCII_COMMAND_LIST, CMD_START, CMD_TERMINATOR,
                       STATUS_ALIVE)
from .dispatcher import Dispatcher
from .messages import Request, Response

if TYPE_CHECKING: # pragma: no cover
    from lumagen.executor import CommandExecutor

INITIAL_READ_SIZE = 4
DEFAULT_READ_BYTES = 8
READ_TIMEOUT = 4

EventCallbackType = (
    Callable[[str, str | None], None] | Callable[[str, str | None], Awaitable[None]]
)


class BufferManager:
    """Manage a data buffer in a streaming context.

    This class provides utility methods for handling a buffer, extracting messages,
    and checking for specific conditions like prefixes or terminators.
    """

    def __init__(self, terminator: str = "\n", ignored_prefixes: tuple = ()) -> None:
        r"""Initialize the buffer manager with a terminator and ignored prefixes.

        Args:
            terminator (str): The character or string that marks the end of a message.
                              Defaults to "\n".
            ignored_prefixes (tuple): A tuple of prefixes to ignore in the buffer.
                                      Defaults to an empty tuple.

        """
        self.terminator = terminator
        self.ignored_prefixes = ignored_prefixes
        self.buffer = ""

    def append(self, data: str) -> None:
        """Append data to the buffer.

        Args:
            data (str): The data to append to the buffer.

        """
        self.buffer += data

    def extract_message(self) -> str:
        """Extract a complete message from the buffer and update the buffer.

        Removes the message if it ends with the terminator.

        Returns:
            str: The extracted message with leading and trailing whitespace stripped.
                 Returns an empty string if no complete message is available.

        """
        end_idx = self.buffer.find(self.terminator) + len(self.terminator)
        if end_idx > 0:
            message = self.buffer[:end_idx]
            self.buffer = self.buffer[end_idx:]
            return message.strip()
        return ""

    def clear(self) -> None:
        """Clear the buffer by removing all its contents."""
        self.buffer = ""

    def starts_with(self, prefixes: tuple) -> bool:
        """Check if the buffer starts with any of the specified prefixes.

        Args:
            prefixes (tuple): A tuple of prefixes to check.

        Returns:
            bool: True if the buffer starts with one of the prefixes, False otherwise.

        """
        return self.buffer.lower().startswith(
            tuple(prefix.lower() for prefix in prefixes)
        )

    def ends_with_terminator(self) -> bool:
        """Check if the buffer ends with the terminator.

        Returns:
            bool: True if the buffer ends with the terminator, False otherwise.

        """
        return self.buffer.endswith(self.terminator)

    def is_empty(self) -> bool:
        """Check if the buffer is empty or contains only whitespace.

        Returns:
            bool: True if the buffer is empty or contains only whitespace, False otherwise.

        """
        return not self.buffer.strip()

    def adjust_buffer(self, keywords: list[str]) -> None:
        """Modify the buffer to start from the first detected keyword."""
        buffer_lower = self.buffer.lower()
        for keyword in keywords:
            start_idx = buffer_lower.find(keyword.lower())

            if start_idx != -1:
                # Special case: If buffer is exactly "#!", do not modify it
                if (
                    keyword == "!"
                    and start_idx == 1
                    and self.buffer[start_idx - 1] == "#"
                    and len(self.buffer) == 2
                ):
                    return

                # Adjust the buffer to start from the keyword
                self.buffer = self.buffer[start_idx:]
                return


@dataclass
class ConnectionConfig:
    """Holds connection settings and parameters."""

    status: ConnectionStatus = ConnectionStatus.DISCONNECTED
    reconnect_enabled: bool = True
    connection_params: dict[str, Any] = field(default_factory=dict)


@dataclass
class SerialConfig:
    """Configuration for serial connections."""

    max_buffer_size: int = 2048
    max_incomplete_duration: int = 10
    timeout: float = 5.0


class ConnectionState(LoggingMixin): # pylint: disable=too-many-instance-attributes
    """Encapsulates the state of the connection for serial and IP communication.

    Provides utility methods for managing the connection state, including
    buffering data, managing command queues, and tracking responses.
    """

    def __init__(self) -> None:
        """Initialize a new ConnectionState instance.

        Attributes:
            buffer (deque[str]): Stores incoming data.
            command_queue (deque): Holds commands to be sent.
            command_response_map (dict[str, str]): Maps commands to their expected responses.
            last_command_byte (str): Stores the last byte of the last command sent.
            sending_command (bool): Tracks whether a command is currently being sent.
            current_command (Optional[str]): Stores the current command being processed.

        """

        super().__init__()
        self.buffer: deque[str] = deque()
        self.command_queue = deque()
        self.command_response_map: dict[str, str] = {}
        self.last_command_byte: str = ""
        self.sending_command: bool = False
        self.current_command: str | None = None
        self.power_changing: bool = False

    def append_to_buffer(self, data: str) -> None:
        """Append data to the buffer.

        Args:
            data (str): The data to append to the buffer.

        """
        self.buffer.extend(data)

    def clear_buffer(self) -> None:
        """Clear the communication buffer."""
        self.buffer.clear()

    def has_pending_commands(self) -> bool:
        """Check if there are commands in the queue.

        Returns:
            bool: True if the command queue is not empty, False otherwise.

        """
        if not self.command_queue:
            self.current_command = None
        return bool(self.command_queue)

    def pop_next_command(self) -> str | None:
        """Retrieve the next command from the queue and update the current command."""
        if self.command_queue:
            self.current_command = self.command_queue.popleft()
            self.log.debug("Commands remaining in queue: %d", len(self.command_queue))
            return self.current_command
        self.log.debug("Queue is empty after pop attempt")
        self.current_command = None
        return None


@dataclass
class ConnectionManager:
    """Manages the connection state and communication handlers for the device."""

    config: ConnectionConfig = field(default_factory=ConnectionConfig)
    handler: SerialHandler | IPHandler = None
    task_manager: TaskManager = field(default_factory=TaskManager)
    dispatcher: Dispatcher = field(default_factory=Dispatcher)
    executor: CommandExecutor = None
    closing: bool = False


class BaseHandler(LoggingMixin):
    """Base handler for managing shared connection logic."""

    def __init__(self, dispatcher: Dispatcher | None = None) -> None:
        """Initialize with common configuration and event callback."""
        super().__init__()
        self._dispatcher: Dispatcher = dispatcher
        self._task_manager = TaskManager()
        self.connection_state = ConnectionState()
        self._state_lock = asyncio.Lock()
        self.reader: asyncio.StreamReader = None
        self.writer: asyncio.StreamWriter = None
        self._pending_requests: dict[str, Request] = {}
        self._response_event = asyncio.Event()

    async def process_stream(self):
        """Process the incoming data stream until the stream ends or is cancelled."""
        buffer_manager = BufferManager(terminator="\n", ignored_prefixes=("#ZC", "#ZT", "#ZY"))

        while True:
            await asyncio.sleep(0)  # Yield to allow cooperative multitasking

            try:
                if not await self._read_single_byte(buffer_manager):
                    await self._handle_stream_termination()
                    break

                await self._handle_additional_data(buffer_manager)

                if await self._should_process_buffer(buffer_manager):
                    await self._handle_buffer_message(buffer_manager)

            except asyncio.CancelledError:
                self.log.debug("Task process_stream cancelled.")
                raise

    async def _handle_stream_termination(self):
        """Handle the end of the data stream."""
        self.log.info("Stream terminated, exiting stream processing loop.")
        self._task_manager.add_task(
            self._dispatcher.invoke_event(
                EventType.CONNECTION_STATE,
                state=ConnectionStatus.DISCONNECTED,
            ),
            "invoke_event",
        )

    async def _handle_additional_data(self, buffer_manager: BufferManager):
        """Read and append additional data if available."""
        data = await self._read_additional_data()
        if data:
            buffer_manager.append(data)

    async def _should_process_buffer(self, buffer_manager: BufferManager) -> bool:
        """Check buffer conditions to decide whether to process a message."""
        if buffer_manager.is_empty():
            buffer_manager.clear()
            return False

        buffer_start = buffer_manager.buffer[:5]
        if not (
            buffer_manager.starts_with(("power", "#", "!")) or
            any(buffer_manager.buffer.startswith(k) for k in ASCII_COMMAND_LIST)
        ):
            self.log.debug("Buffer start '%s' does not match known patterns", buffer_start)

        self.log.debug("Buffer updated: %s", buffer_manager.buffer.encode())

        buffer_manager.adjust_buffer(["power", "#ZQS1", "!", "#"])

        if buffer_manager.starts_with(buffer_manager.ignored_prefixes):
            buffer_manager.clear()
            return False

        if (
            buffer_manager.starts_with(("power", "#", "!")) and
            buffer_manager.ends_with_terminator()
        ):
            return True

        if buffer_manager.ends_with_terminator():
            buffer_manager.clear()
            return False

        key, value, is_keypress = process_command_or_keypress(
            buffer_manager.buffer,
            ASCII_COMMAND_LIST
        )
        if key:
            log_msg = (
                f"Received Keypress Command: {value}" if is_keypress
                else f"Received Remote Command: {value}"
            )
            self.log.debug(log_msg)
            buffer_manager.clear()
            self._response_event.set()
            return False

        return False

    async def _handle_buffer_message(self, buffer_manager: BufferManager):
        """Extract and process the message from the buffer."""
        message = buffer_manager.extract_message()
        if not message:
            self.log.debug("No valid message extracted from buffer")
            self._response_event.set()
            return

        self.log.debug("Processing Message: %s", message)

        if "power" in message.lower():
            self.connection_state.power_changing = False
            self.log.info("Power sequence completed. Commands can resume.")

        try:
            response = Response.factory(message)
            req = self._pending_requests.pop(response.name, None)
            if req:
                req.set(response)
            else:
                await self._dispatcher.invoke_event(
                    EventType.DATA_RECEIVED,
                    response=response,
                    message=response.name,
                )
        except ValueError as ex:
            self.log.error(ex)

        self._response_event.set()

    async def _read_single_byte(self, buffer_manager: BufferManager) -> bool:
        """Read a single byte and append it to the buffer."""
        single_byte = await self.reader.read(1)
        if not single_byte:
            self.log.warning("Stream ended unexpectedly")
            return False

        buffer_manager.append(single_byte.decode("utf-8"))
        return True

    async def _read_additional_data(self) -> str:
        """Read additional data from the stream with timeout."""
        for read_func in [
            lambda: self.reader.readuntil(separator=b"\n"),
            lambda: self.reader.read(1024),
        ]:
            try:
                data: bytes = await asyncio.wait_for(read_func(), timeout=0.2)
                return data.decode("utf-8") if data else ""
            except asyncio.exceptions.TimeoutError:
                continue
        return ""

    @abstractmethod
    async def _send_bytes(self, data: bytes) -> None:
        """Send raw bytes over the connection (implemented by subclasses)."""

    async def send(self, data: bytes | Request) -> Response | None:
        """Send raw bytes or a Request to the hardware."""
        if isinstance(data, Request):
            key = data.name.removeprefix("ZQ")
            self._pending_requests[key] = data
            await self.queue_command(data.name)
            try:
                return await asyncio.wait_for(data.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                self.log.warning("Timeout waiting for response to request: %s", data.name)
                self._pending_requests.pop(data.name, None)
                return None
        else:
            await self._send_bytes(data)

    async def queue_command(self, command: str | list[str]):
        """Queue a command or multiple commands to be sent over an active connection."""

        if isinstance(command, str):
            command = [command]  # Convert single command to a list

        if not isinstance(command, list):
            self.log.error("Invalid command type: %s", type(command).__name__)
            return

        valid_commands = [cmd.strip() for cmd in command if isinstance(cmd, str) and cmd.strip()]
        if not valid_commands:
            self.log.error("No valid commands to queue.")
            return

        is_alive_check = any(cmd in STATUS_ALIVE for cmd in valid_commands)
        is_power_command = any(cmd in {"%", "$"} for cmd in valid_commands)

        if self.connection_state.power_changing and not is_alive_check:
            self.log.warning("Cannot queue commands while power transition is active.")
            return

        if is_power_command:
            self.connection_state.power_changing = True
            self.log.info("Power transition started. Blocking other command execution.")

            asyncio.create_task(self._power_transition_timeout())

        self.connection_state.command_queue.extend(valid_commands)
        self.log.debug(
            "Queued %d commands. Commands remaining: %d",
            len(valid_commands),
            len(self.connection_state.command_queue)
        )

        self.process_next_command()

    def process_next_command(self):
        """Trigger processing of the next command in the queue."""
        if not self._task_manager.get_task("process_next_command"):
            self._task_manager.add_task(
                self._process_next_command(),
                "process_next_command",
            )

    async def _process_next_command(self):
        """Process the next command in the queue if no command is currently being sent."""
        iteration_count = 0

        while True:
            async with self._state_lock:

                if self._should_exit_processing():
                    self.log.debug("No more commands in the queue. Exiting loop\n")
                    break

                command: str = self.connection_state.pop_next_command()
                if not command:
                    continue

                data: bytes = CMD_START + command.encode("utf-8") + CMD_TERMINATOR

            await self.send(data)

            ignored_prefixes = ("ZC", "ZT", "ZY")

            if any(command.startswith(prefix) for prefix in ignored_prefixes):
                return

            self._response_event.clear()

            try:
                await asyncio.wait_for(self._response_event.wait(), timeout=5.0)
            except asyncio.exceptions.TimeoutError:
                self.log.warning("Timed out waiting for solicited response.")

    def _should_exit_processing(self) -> bool:
        """Check conditions to exit the processing loop."""
        if self.connection_state.sending_command:
            return True

        if not self.connection_state.has_pending_commands():
            return True

        return False

    async def _power_transition_timeout(self, timeout: int = 30):
        """Fail-safe: Reset power_changing if power transition takes too long."""
        await asyncio.sleep(timeout)

        if self.connection_state.power_changing:
            self.log.warning("Power transition timeout exceeded! Resetting system state.")
            self.connection_state.power_changing = False
            self.process_next_command()

    async def close(self):
        """Clean up tasks and close the connection."""
        with contextlib.suppress(asyncio.CancelledError):
            await self._task_manager.cancel_all_tasks()

        await self._task_manager.wait_for_all_tasks()
        self.log.info("All tasks cancelled and connection closed.")


class SerialHandler(BaseHandler, asyncio.Protocol):
    """Handles serial communication using asyncio."""

    def __init__(
        self,
        dispatcher: Dispatcher | None = None,
    ) -> None:
        """Initialize."""
        super().__init__(dispatcher)

        self.transport: asyncio.Transport | None = None
        self.config = SerialConfig()
        self._state_lock = asyncio.Lock()

    def connection_made(self, transport: serial_asyncio.SerialTransport) -> None:
        """Made Connection."""
        self.transport = transport
        self.reader = asyncio.StreamReader()
        self.log.info("Serial connection established")

        transport.serial.reset_input_buffer()
        transport.serial.reset_output_buffer()

        self._task_manager.add_task(
            self._dispatcher.invoke_event(
                EventType.CONNECTION_STATE,
                state=ConnectionStatus.CONNECTED,
                message=f"Connected to {transport.serial.port}",
            ),
            "invoke_event",
        )

        self._task_manager.add_task(self.process_stream(), "process_stream")

    def connection_lost(self, exc) -> None:
        """Lost Connection."""
        self.transport = None
        self.log.warning("Serial connection lost")

        # Schedule the async method separately
        asyncio.create_task(  # noqa: RUF006
            self._dispatcher.invoke_event(
                EventType.CONNECTION_STATE,
                state=ConnectionStatus.DISCONNECTED,
                message=str(exc),
            )
        )

    def data_received(self, data) -> None:
        """Call automatically when data is received."""

        self.reader.feed_data(data)

    @staticmethod
    def extract_serial_transport_details(
        transport: serial_asyncio.SerialTransport,
    ) -> dict[str, Any]:
        """Extract details from the SerialTransport object and format as a dictionary.

        Returns:
            - A dictionary of extracted transport details if available.
            - {"error": "No transport details available"} if all attributes are None.
            - {"error": "Could not extract transport details"} if an AttributeError occurs.

        """
        try:
            serial = transport.serial
            if serial:
                details = {
                    "port": serial.port,
                    "baudrate": serial.baudrate,
                    "bytesize": serial.bytesize,
                    "parity": serial.parity,
                    "stopbits": serial.stopbits,
                    "timeout": serial.timeout,
                    "xonxoff": serial.xonxoff,
                    "rtscts": serial.rtscts,
                    "dsrdtr": serial.dsrdtr,
                }

                # Return a consistent dictionary even if all values are None
                return (
                    details
                    if any(value is not None for value in details.values())
                    else {"error": "No transport details available"}
                )

        except AttributeError:
            return {"error": "Could not extract transport details"}

        return {"error": "No serial transport available"}

    @classmethod
    async def open_connection(
        cls, port: str, baudrate: int, dispatcher=None
    ) -> SerialHandler:
        """Open an asynchronous serial connection."""

        # Create an instance temporarily to access the instance-level logger
        temp_instance = cls(dispatcher)

        loop = asyncio.get_running_loop()

        result = await serial_asyncio.create_serial_connection(
            loop, lambda: cls(dispatcher), port, baudrate
        )

        if isinstance(result, tuple) and len(result) == 2:
            transport, protocol = result
            transport_details = cls.extract_serial_transport_details(transport)

            temp_instance.log.debug("Transport Details:")
            custom_log_pprint(transport_details, temp_instance.log.debug)

            return protocol

        raise TypeError(
            "Expected (transport, protocol) tuple from create_serial_connection, "
            f"but got {type(result).__name__}: {result}"
        )

    async def _send_bytes(self, data: bytes) -> None:
        """Send raw bytes over the serial connection."""
        if not self.transport:
            self.log.error("Cannot send data: No active connection.")
            return
        self.transport.write(data)
        self.log.debug("Command sent: %s", data)


class IPHandler(BaseHandler):
    """Handles IP (TCP) communication."""

    async def open_connection(self, host: str, port: int) -> IPHandler:
        """Open an asynchronous ip connection."""
        self.reader, self.writer = await asyncio.open_connection(host, port)
        self.log.info("IP connection established to %s:%d", host, port)

        self._task_manager.add_task(
            self._dispatcher.invoke_event(
                EventType.CONNECTION_STATE,
                state=ConnectionStatus.CONNECTED,
                message=f"Connected to {host}:{port}",
            ),
            "invoke_event",
        )

        self._task_manager.add_task(self.process_stream(), "process_stream")

    async def _send_bytes(self, data: bytes) -> None:
        """Send raw bytes over the IP connection."""
        if self.writer is None or self.writer.is_closing():
            raise ConnectionError("Writer is closed or unavailable")
        self.writer.write(data)
        await self.writer.drain()
        self.log.debug("Sent bytes: %s", data)

    async def close(self) -> None:
        """Close."""
        await super().close()
        if self.writer:
            self.writer.close()
            try:
                await asyncio.wait_for(self.writer.wait_closed(), timeout=5.0)
            except asyncio.exceptions.TimeoutError:
                self.log.warning("Timeout while waiting for writer to close.")
            finally:
                self.writer = None
                self.reader = None

            self._task_manager.add_task(
                self._dispatcher.invoke_event(
                    EventType.CONNECTION_STATE,
                    state=ConnectionStatus.DISCONNECTED,
                    message="Disconnected from host",
                ),
                "invoke_event",
            )

def process_command_or_keypress(
    buffer: str, my_dict: dict[str, str]
) -> tuple[str | None, str | None, bool]:
    """Check if the buffer matches a command or keypress in the dictionary.

    Args:
        buffer (str): The current buffer to check.
        my_dict (dict): The dictionary of commands or keypress mappings.

    Returns:
        tuple: (key, value, is_keypress) where:
            - key (str or None): The matched command/key.
            - value (str or None): The associated value for the matched command/key.
            - is_keypress (bool): True if it's a keypress, False otherwise.

    """

    # Sort by key length descending to match multi-char keys before partial ones
    for key in sorted(my_dict.keys(), key=len, reverse=True):
        value = my_dict[key]
        if buffer.startswith("#" + key):
            return key, value, False
        if buffer.startswith(key):
            return key, value, True
    return None, None, False
