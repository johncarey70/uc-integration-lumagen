"""Utility Classes for Logging."""

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any, Protocol


@asynccontextmanager
async def suppress_debug_logging():
    """Temporarily disable debug logging during a block of async code.

    Ensures debug logs are suppressed during the body of the context and 
    reliably re-enabled after, even if an error occurs.
    """

    LoggingMixin.disable_debug_logging()
    try:
        yield
        await asyncio.sleep(0.5)
    finally:
        LoggingMixin.enable_debug_logging()

class LogProtocol(Protocol):
    """Protocol defining standard logging methods for structured logging."""

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a debug message.

        Used for detailed debugging information useful during development.
        """

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an informational message.

        Used for general application events that highlight progress or state changes.
        """

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a warning message.

        Used to indicate potential issues or unexpected behavior that isn't critical.
        """

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an error message.

        Used for serious issues that might affect the application's execution.
        """

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a critical error message.

        Used for severe errors that may lead to application failure.
        """


class LoggingMixin:
    """Mixin class providing dynamic logging with classname."""

    _disable_debug_logging = False

    log: LogProtocol

    def __init__(self) -> None:
        """Initialize the logger for the current module."""
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__module__)

    def log_debug(self, message: str, *args: Any) -> None:
        """Log a debug message only if debug logging is enabled."""
        if not LoggingMixin._disable_debug_logging:
            self.logger.debug(
                message,
                *args,
                extra={"classname": self.__class__.__name__},
                stacklevel=3,
            )

    def log_info(self, message: str, *args: Any) -> None:
        """Log an info message."""
        self.logger.info(
            message, *args, extra={"classname": self.__class__.__name__}, stacklevel=3
        )

    def log_warning(self, message: str, *args: Any) -> None:
        """Log a warning message."""
        self.logger.warning(
            message, *args, extra={"classname": self.__class__.__name__}, stacklevel=3
        )

    def log_error(self, message: str, *args: Any) -> None:
        """Log an error message."""
        self.logger.error(
            message, *args, extra={"classname": self.__class__.__name__}, stacklevel=3
        )

    def log_critical(self, message: str, *args: Any) -> None:
        """Log a critical message."""
        self.logger.critical(
            message, *args, extra={"classname": self.__class__.__name__}, stacklevel=3
        )

    @classmethod
    def disable_debug_logging(cls) -> None:
        """Disable all debug logs globally."""
        cls._disable_debug_logging = True

    @classmethod
    def enable_debug_logging(cls) -> None:
        """Enable debug logging globally."""
        cls._disable_debug_logging = False

    def __getattr__(self, name: str) -> Any:
        """Provide dynamic access to the log property."""
        if name == "log":
            return LogProxy(self)
        raise AttributeError(
            f"'{self.__class__.__name__}' object has no attribute '{name}'"
        )


class LogProxy:
    """Proxy to dynamically map log levels to LoggingMixin methods."""

    def __init__(self, base_instance: Any) -> None:
        """Initialize the log proxy with the given base instance."""
        self.base_instance = base_instance

    def __getattr__(self, log_level: str) -> Any:
        """Dynamically map log levels to corresponding methods in LoggingMixin."""
        log_method_name = f"log_{log_level}"
        try:
            return getattr(self.base_instance, log_method_name)
        except AttributeError as e:
            raise AttributeError(f"No log method for level '{log_level}'") from e

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a debug message."""
        getattr(self.base_instance, "log_debug")(msg, *args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an informational message."""
        getattr(self.base_instance, "log_info")(msg, *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a warning message."""
        getattr(self.base_instance, "log_warning")(msg, *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an error message."""
        getattr(self.base_instance, "log_error")(msg, *args, **kwargs)

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a critical message."""
        getattr(self.base_instance, "log_critical")(msg, *args, **kwargs)


def custom_log_pprint(
    data: dict | list | str, log_method: callable, indent: int = 0
) -> None:
    """Pretty-print dictionaries and lists using the specified logging method."""

    def format_data(value: dict | list | str | float | bool, level: int) -> str:
        """Format nested data (dicts, lists, and other types) with proper indentation."""
        if isinstance(value, dict):
            return format_nested_dict(value, level)

        if isinstance(value, list):
            return format_list(value, level)

        if isinstance(value, str):
            return f"'{value}'"

        return str(value)

    def format_nested_dict(d: dict, level: int = 0) -> str:
        """Recursively format nested dictionaries with indentation."""
        spaces = "    " * level
        formatted = f"{spaces}{{\n"
        for key, value in d.items():
            formatted += f"{spaces}    '{key}': {format_data(value, level + 1)},\n"
        formatted += f"{spaces}}}"
        return formatted

    def format_list(lst: list, level: int = 0) -> str:
        """Recursively format lists with correct indentation (exactly 4 spaces per item)."""
        spaces = "    " * level
        item_indent = "    " * (level + 1)

        formatted = f"{spaces}[\n"
        for item in lst:
            formatted += f"{item_indent}{format_data(item, 0)},\n"
        formatted += f"{spaces}]"
        return formatted

    formatted_output = (
        format_list(data, indent)
        if isinstance(data, list)
        else format_data(data, indent)
    )

    log_method("\n" + formatted_output)
