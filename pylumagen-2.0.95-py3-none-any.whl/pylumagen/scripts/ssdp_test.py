#!/usr/bin/env python3

import socket
import struct
import time
from typing import List

SSDP_MULTICAST = "239.255.255.250"
SSDP_PORT = 1900
MSEARCH_MSG = ("M-SEARCH * HTTP/1.1\r\n"
              "HOST: 239.255.255.250:1900\r\n"
              "MAN: \"ssdp:discover\"\r\n"
              "MX: 2\r\n"
              "ST: ssdp:all\r\n\r\n")

def send_ssdp_discovery(timeout: int = 5) -> List[str]:
    """Send an SSDP M-SEARCH request and collect responses."""
    responses = []
    
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(timeout)
    
    try:
        # Send M-SEARCH request to the SSDP multicast address
        sock.sendto(MSEARCH_MSG.encode(), (SSDP_MULTICAST, SSDP_PORT))
        print("SSDP discovery request sent...")
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                data, addr = sock.recvfrom(1024)
                response = data.decode(errors='ignore')
                responses.append(response)
                print(f"Received SSDP response from {addr[0]}:\n{response}\n")
            except socket.timeout:
                break
    finally:
        sock.close()
    
    return responses

def listen_for_ssdp_notifications(timeout: int = 10) -> List[str]:
    """Listen for SSDP NOTIFY messages."""
    notifications = []
    
    # Create a UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("", SSDP_PORT))
    
    # Join the multicast group
    group = socket.inet_aton(SSDP_MULTICAST)
    mreq = struct.pack("4s4s", socket.inet_aton(SSDP_MULTICAST), socket.inet_aton("192.168.15.252"))  
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    
    print("Listening for SSDP NOTIFY messages...")
    
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            data, addr = sock.recvfrom(1024)
            message = data.decode(errors='ignore')
            notifications.append(message)
            print(f"Received SSDP NOTIFY from {addr[0]}:\n{message}\n")
        except socket.timeout:
            break
    
    sock.close()
    return notifications

if __name__ == "__main__":
    print("Starting SSDP discovery...")
    send_ssdp_discovery()
    print("Listening for SSDP notifications...")
    listen_for_ssdp_notifications()
