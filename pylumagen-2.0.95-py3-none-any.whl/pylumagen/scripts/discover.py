#!/usr/bin/env python3

__version__ = "0.15"

import json
import re
import select
import socket
import time
from contextlib import contextmanager
from http.client import HTTPResponse
from struct import pack
from urllib.error import HTTPError
from urllib.request import urlopen
from uuid import getnode as get_mac

import xmltodict

SSDP_ALL = "ssdp:all"
SSDP_GROUP = ("239.255.255.250", 1900)
URN_AVTransport_Fmt = "urn:schemas-upnp-org:service:AVTransport:{}"

def _get_location_url(raw):
    t = re.findall("\nlocation: (.*)", raw, flags=re.M|re.I)
    if len(t) > 0:
        return t[0]
    return ''

class DlnapDevice:

    def __init__(self, raw: bytes, ip: str):

        self.ip = ip
        self.name: str = ""
        self.__raw = raw.decode()
        self.location = _get_location_url(self.__raw)
        self.rendering_control_url = None
        data_dict = None
        response: HTTPResponse = None
        try:
            with urlopen(self.location) as response:
                raw_desc_xml = response.read().decode()
                data_dict = xmltodict.parse(raw_desc_xml)
                if data_dict is not None:
                    json_str = json.dumps(data_dict, indent=4, sort_keys=True)
                else:
                    return
        except HTTPError:
            return

        device = data_dict["root"]["device"]
        self.name = device["friendlyName"]

        if "Altitude" in self.name:
            print(json_str)

    def __repr__(self):
        return f'{self.name} @ {self.ip}'

    def __eq__(self, d):
        return self.name == d.name and self.ip == d.ip

@contextmanager
def _send_udp(ssdp_grp: tuple, packet: str):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.sendto(packet.encode(), ssdp_grp)
    yield sock
    sock.close()

def discover(timeout=2, st=SSDP_ALL, mx=3, ssdp_version=1):
    st = st.format(ssdp_version)
    payload = "\r\n".join([
                'M-SEARCH * HTTP/1.1',
                f'User-Agent: {__file__}/{__version__}',
                f'HOST: {SSDP_GROUP[0]}:{SSDP_GROUP[1]}',
                'Accept: */*',
                'MAN: "ssdp:discover"',
                f'ST: {st}',
                f'MX: {mx}',
                '',
                ''])

    devices = []

    with _send_udp(SSDP_GROUP, payload) as sock:
        start = time.time()
        while True:
            if time.time() - start > timeout:
                break
            r, w, x = select.select([sock], [], [sock], 1)
            if sock in r:
                data, addr = sock.recvfrom(1024)

                print(data)
                d = DlnapDevice(data, addr[0])
                if d not in devices:
                    #if "altitude" in d.name.lower():
                    devices.append(d)
            elif sock in w:
                pass
            elif sock in x:
                raise SendUDPError
            else:
                pass
    return devices

class SendUDPError(Exception):
    """Getting response failed"""

if __name__ == '__main__':

    for num in range(10):
        #allDevices = discover(timeout=2, st=URN_AVTransport_Fmt, ssdp_version=1)
        allDevices = discover(timeout=2, st=SSDP_ALL, ssdp_version=1)
        if not allDevices:
            print(num)
            continue

        print('Discovered devices:')
        dev: DlnapDevice = None
        for dev in allDevices:
            print(dev.name)
            print(dev.ip)
        break

    # dest_ip = [192, 168, 15, 30]
    # local_mac = [0x00, 0x21, 0xb9, 0x02, 0x60, 0xa1]
    # local_ip = [192, 168, 15, 19]

    # ARP_FRAME = [
    #     pack('!H', 0x0001), # HRD
    #     pack('!H', 0x0800), # PRO
    #     pack('!B', 0x06), # HLN
    #     pack('!B', 0x04), # PLN
    #     pack('!H', 0x0001), # OP
    #     pack('!6B', *local_mac), # SHA
    #     pack('!4B', *local_ip), # SPA
    #     pack('!6B', *(0x00,)*6), # THA
    #     pack('!4B', *dest_ip), # TPA
    # ]

    # s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3))

    # print(ARP_FRAME)
    # s.sendto(b''.join(ARP_FRAME), ('255.255.255.255', 0))
    # s.close()
