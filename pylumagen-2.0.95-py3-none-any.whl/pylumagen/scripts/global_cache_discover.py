#!/usr/bin/env python3

import socket
import struct

MULTICAST_IP = "239.255.250.250"  # Global Cache Multicast Address
PORT = 9131
MESSAGE = "GlobalCacheDiscovery"


def send_discovery():
    """Send Global Cache discovery request via multicast."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    
    print(f"Sending Global Cache discovery request to {MULTICAST_IP}:{PORT}...")
    sock.sendto(MESSAGE.encode(), (MULTICAST_IP, PORT))
    sock.settimeout(5)
    
    try:
        while True:
            data, addr = sock.recvfrom(1024)
            print(f"Received response from {addr[0]}:\n{data.decode()}\n")
    except socket.timeout:
        print("No more responses received.")
    finally:
        sock.close()


def listen_for_responses():
    """Listen for Global Cache device announcements via multicast."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("", PORT))
    
    mreq = struct.pack("4sl", socket.inet_aton(MULTICAST_IP), socket.INADDR_ANY)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    
    print(f"Listening for Global Cache announcements on {MULTICAST_IP}:{PORT}...")
    
    try:
        while True:
            data, addr = sock.recvfrom(1024)
            print(f"Received announcement from {addr[0]}:\n{data.decode()}\n")
    except KeyboardInterrupt:
        print("Stopping listener.")
    finally:
        sock.close()


def main():
    print("Starting Global Cache device discovery...")
    send_discovery()
    print("Listening for Global Cache device announcements...")
    listen_for_responses()


if __name__ == "__main__":
    main()
