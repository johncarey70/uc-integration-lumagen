"""Configuration settings for the Lumagen package."""

# Default communication settings
DEFAULT_BAUDRATE = 9600
DEFAULT_BUFFER_SIZE = 1024
DEFAULT_IP_PORT = 4999
DEFAULT_HEALTH_CHECK_INTERVAL = 30
